#!/usr/bin/env node
/*
 * Office Coffee Station — local server
 * ------------------------------------
 * One file, no dependencies: needs only Node.js 18 or newer.
 *
 *   node server.js                         start the server
 *   node server.js create-admin EMAIL NAME create (or reset) an admin account; prints a password
 *   node server.js reset-password EMAIL    give a barista/admin a new password
 *
 * Settings (environment variables, all optional):
 *   PORT=8080            port to listen on
 *   HOST=0.0.0.0         0.0.0.0 = reachable from other PCs on the network
 *   DATA_DIR=./data      where the database, backups and uploaded photos live
 *   COOKIE_SECURE=1      set when the site is served over HTTPS (behind IIS / Nginx / Caddy)
 *   TRUST_PROXY=1        set when behind a reverse proxy, so client IPs are read correctly
 */
'use strict'

const http = require('http')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

const ROOT = __dirname
const PUBLIC_DIR = path.join(ROOT, 'public')
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'))
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads')
const BACKUP_DIR = path.join(DATA_DIR, 'backups')
const DB_FILE = path.join(DATA_DIR, 'db.json')
const PORT = Number(process.env.PORT) || 8080
const HOST = process.env.HOST || '0.0.0.0'
const COOKIE_SECURE = process.env.COOKIE_SECURE === '1'
const TRUST_PROXY = process.env.TRUST_PROXY === '1'
const COOKIE = 'coffee_session'
const MAX_QTY = 10
const STATUSES = ['new', 'preparing', 'ready', 'completed', 'cancelled']
const TRANSITIONS = {
  new: ['preparing', 'cancelled'],
  preparing: ['ready', 'new', 'cancelled'],     // 'new' = undo
  ready: ['completed', 'preparing'],            // 'preparing' = undo
  completed: [],
  cancelled: []
}
const KEEP_ORDERS_DAYS = 365
const KEEP_BACKUPS = 14

/* ============================== storage ============================== */
// The whole database is one JSON file. It is small (a year of orders is a
// few MB), kept in memory, and written atomically: first to db.json.tmp,
// then renamed over db.json, so a power cut can never leave half a file.

for (const d of [DATA_DIR, UPLOAD_DIR, BACKUP_DIR]) fs.mkdirSync(d, { recursive: true })

const newId = (n = 12) => crypto.randomBytes(n).toString('base64url')
const now = () => Date.now()

function defaultProducts() {
  const list = [
    ['Espresso', 'A short, intense shot of coffee.', 'espresso'],
    ['Americano', 'Espresso topped up with hot water.', 'americano'],
    ['Cappuccino', 'Espresso, steamed milk and thick foam.', 'cappuccino'],
    ['Caffè Latte', 'Espresso with plenty of silky milk.', 'latte'],
    ['Spanish Latte', 'Latte sweetened with condensed milk.', 'spanish-latte'],
    ['Flat White', 'Double ristretto, velvety microfoam.', 'flat-white'],
    ['Cortado', 'Espresso cut with an equal splash of warm milk.', 'cortado'],
    ['Mocha', 'Espresso, chocolate and steamed milk.', 'mocha'],
    ['Matcha', 'Japanese green tea whisked with steamed milk.', 'matcha'],
    ['Matcha Vanilla', 'Matcha latte with a touch of vanilla.', 'matcha-vanilla'],
    ['Hot Chocolate', 'Creamy chocolate with steamed milk.', 'hot-chocolate'],
    ['Tea', 'Freshly brewed black tea.', 'tea']
  ]
  return list.map(([name, desc, img], i) => ({ id: newId(6), name, desc, image: `/images/${img}.svg`, active: true, sort: i + 1 }))
}

function parseCsv(text) {
  const rows = []
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim()
    if (!line) continue
    const cells = []
    let cur = '', q = false
    for (let i = 0; i < line.length; i++) {
      const c = line[i]
      if (q) { if (c === '"' && line[i + 1] === '"') { cur += '"'; i++ } else if (c === '"') q = false; else cur += c }
      else if (c === '"') q = true
      else if (c === ',' || c === '\t') { cells.push(cur.trim()); cur = '' }
      else cur += c
    }
    cells.push(cur.trim())
    rows.push(cells)
  }
  return rows
}

/** Rows of [first, last, email] in any column order → clean staff records. */
function staffFromRows(rows) {
  const out = [], skipped = []
  for (const cells of rows) {
    const ei = cells.findIndex(c => EMAIL_RE.test(c))
    if (ei === -1) { if (!cells.some(c => /e-?mail/i.test(c))) skipped.push(cells.join(' ')); continue }
    const others = cells.filter((c, i) => i !== ei && c)
    if (!others[0]) { skipped.push(cells.join(' ')); continue }
    out.push({ email: cells[ei].toLowerCase(), firstName: others[0].slice(0, 40), lastName: (others[1] || '').slice(0, 40), active: true })
  }
  return { rows: out, skipped }
}

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/

function freshDb() {
  const db = {
    version: 1,
    settings: { cafeName: 'Office Coffee', orderPrefix: '', nextOrderNumber: 101 },
    staff: [], users: [], products: defaultProducts(), orders: [], sessions: {}
  }
  const seed = path.join(ROOT, 'seed', 'staff.csv')
  if (fs.existsSync(seed)) db.staff = staffFromRows(parseCsv(fs.readFileSync(seed, 'utf8'))).rows
  return db
}

function loadDb() {
  if (!fs.existsSync(DB_FILE)) return freshDb()
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))
  } catch (e) {
    console.error(`\n!!! ${DB_FILE} is damaged (${e.message}).`)
    console.error('!!! Restore the newest file from data/backups/ (copy it over data/db.json), then start again.\n')
    process.exit(1)
  }
}

let db = loadDb()
let saveTimer = null
function save() { if (!saveTimer) saveTimer = setTimeout(flush, 120) }
function flush() {
  clearTimeout(saveTimer); saveTimer = null
  const tmp = DB_FILE + '.tmp'
  const text = JSON.stringify(db)
  try {
    fs.writeFileSync(tmp, text)
    fs.renameSync(tmp, DB_FILE)
  } catch (e) {
    // Some antivirus tools briefly lock files on Windows; fall back to a direct write.
    try { fs.writeFileSync(DB_FILE, text) } catch (e2) { console.error('Could not save the database:', e2.message) }
  }
}

function backup() {
  try {
    if (!fs.existsSync(DB_FILE)) flush()
    const day = new Date().toISOString().slice(0, 10)
    fs.copyFileSync(DB_FILE, path.join(BACKUP_DIR, `db-${day}.json`))
    const files = fs.readdirSync(BACKUP_DIR).filter(f => /^db-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort()
    for (const f of files.slice(0, Math.max(0, files.length - KEEP_BACKUPS))) fs.unlinkSync(path.join(BACKUP_DIR, f))
  } catch (e) { console.error('Backup failed:', e.message) }
}

function housekeeping() {
  const cutoff = now() - KEEP_ORDERS_DAYS * 86400000
  const before = db.orders.length
  db.orders = db.orders.filter(o => o.createdAt >= cutoff)
  for (const [k, s] of Object.entries(db.sessions)) if (s.exp < now()) delete db.sessions[k]
  if (db.orders.length !== before) console.log(`Housekeeping: removed ${before - db.orders.length} orders older than ${KEEP_ORDERS_DAYS} days`)
  save()
}

/* ============================== accounts ============================== */

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex')
  return { salt, hash }
}
function checkPassword(user, password) {
  const { hash } = hashPassword(password, user.salt)
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(user.hash, 'hex'))
}
const randomPassword = () => crypto.randomBytes(9).toString('base64url').replace(/[-_]/g, 'x')

function staffName(s) {
  const f = (s.firstName || '').trim(), l = (s.lastName || '').trim()
  return !l || l.toLowerCase() === f.toLowerCase() ? f : `${f} ${l}`
}

function createSession(kind, ref, days) {
  const token = newId(32)
  const key = crypto.createHash('sha256').update(token).digest('hex')
  db.sessions[key] = { kind, ref, exp: now() + days * 86400000 }
  save()
  return { token, maxAge: days * 86400 }
}

/** Who is making this request? Returns null for nobody. */
function whoIs(req) {
  const token = parseCookies(req)[COOKIE]
  if (!token) return null
  const key = crypto.createHash('sha256').update(token).digest('hex')
  const s = db.sessions[key]
  if (!s || s.exp < now()) return null
  if (s.kind === 'staff') {
    const st = db.staff.find(x => x.email === s.ref && x.active)
    if (!st) return null
    return { key, kind: 'staff', role: 'employee', owner: 'staff:' + st.email, email: st.email, name: staffName(st) }
  }
  const u = db.users.find(x => x.id === s.ref && x.active)
  if (!u) return null
  return { key, kind: 'user', role: u.role, owner: 'user:' + u.id, email: u.email, name: u.name, id: u.id }
}

/* ============================== http helpers ============================== */

function parseCookies(req) {
  const out = {}
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=')
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim())
  }
  return out
}
function setCookie(res, value, maxAge) {
  res.setHeader('Set-Cookie', `${COOKIE}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${COOKIE_SECURE ? '; Secure' : ''}`)
}
function clientIp(req) {
  if (TRUST_PROXY && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim()
  return req.socket.remoteAddress || '?'
}

class HttpError extends Error { constructor(status, message) { super(message); this.status = status } }
const fail = (status, message) => { throw new HttpError(status, message) }

function send(res, status, data) {
  const body = JSON.stringify(data ?? {})
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
  res.end(body)
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0
    req.on('data', c => {
      size += c.length
      if (size > limit) { reject(new HttpError(413, 'That is too large to upload.')); req.destroy(); return }
      chunks.push(c)
    })
    req.on('end', () => resolve(Buffer.concat(chunks)))
    req.on('error', reject)
  })
}
async function readJson(req) {
  const buf = await readBody(req, 300 * 1024)
  if (!buf.length) return {}
  try { return JSON.parse(buf.toString('utf8')) } catch { fail(400, 'The request was not valid JSON.') }
}

// Very small rate limiter: key → list of timestamps.
const hits = new Map()
function limit(key, max, windowMs) {
  const t = now(), arr = (hits.get(key) || []).filter(x => t - x < windowMs)
  if (arr.length >= max) fail(429, 'Too many attempts. Please wait a few minutes and try again.')
  arr.push(t); hits.set(key, arr)
}
function clearLimit(key) { hits.delete(key) }
setInterval(() => { const t = now(); for (const [k, a] of hits) if (!a.some(x => t - x < 3600000)) hits.delete(k) }, 600000).unref()

/* ============================== live updates (SSE) ============================== */
// Browsers keep one /api/events connection open. When something changes we
// send a tiny "orders changed" / "menu changed" message and the page reloads
// just that data. EventSource reconnects by itself if the network drops.

const clients = new Set()
function broadcast(type, test) {
  for (const c of clients) {
    if (test && !test(c.who)) continue
    try { c.res.write(`event: ${type}\ndata: ${now()}\n\n`) } catch { /* closed */ }
  }
}
setInterval(() => { for (const c of clients) { try { c.res.write(': ping\n\n') } catch { /* closed */ } } }, 25000).unref()
const isStaffRole = (w) => w && (w.role === 'barista' || w.role === 'admin')
const ordersChanged = (owner) => broadcast('orders', w => isStaffRole(w) || w.owner === owner)

/* ============================== domain helpers ============================== */

const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime() }
const publicOrder = (o) => ({ id: o.id, number: o.number, name: o.name, items: o.items, notes: o.notes, status: o.status, createdAt: o.createdAt, updatedAt: o.updatedAt })
const str = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '')

function requireUser(req) { const w = whoIs(req); if (!w) fail(401, 'Please sign in again.'); return w }
function requireRole(req, ...roles) { const w = requireUser(req); if (!roles.includes(w.role)) fail(403, 'Your account is not allowed to do that.'); return w }

function placeOrder(w, body) {
  const requestId = str(body.requestId, 64)
  if (requestId) {
    const dup = db.orders.find(o => o.owner === w.owner && o.requestId === requestId)
    if (dup) return dup // same click sent twice → same order
  }
  // Abuse guard: at most 6 real orders a minute per person (mistakes don't count).
  if (db.orders.filter(o => o.owner === w.owner && o.createdAt > now() - 60000).length >= 6) fail(429, 'That is a lot of orders in one minute. Please wait a moment.')
  if (!Array.isArray(body.items) || !body.items.length) fail(400, 'Your order is empty.')
  if (body.items.length > 20) fail(400, 'Too many different drinks in one order.')
  const qty = new Map()
  for (const it of body.items) {
    const q = it && it.qty
    if (!it || typeof it.productId !== 'string' || !Number.isInteger(q) || q < 1 || q > MAX_QTY) fail(400, `Each drink needs a quantity from 1 to ${MAX_QTY}.`)
    qty.set(it.productId, (qty.get(it.productId) || 0) + q)
  }
  const items = []
  for (const [pid, q] of qty) {
    const p = db.products.find(x => x.id === pid && x.active)
    if (!p) fail(409, 'One of your drinks is no longer available. Please check your order.')
    if (q > MAX_QTY) fail(400, `Maximum ${MAX_QTY} of the same drink per order.`)
    items.push({ productId: p.id, name: p.name, image: p.image, qty: q })
  }
  items.sort((a, b) => (db.products.find(p => p.id === a.productId).sort - db.products.find(p => p.id === b.productId).sort))
  const number = `${db.settings.orderPrefix || ''}${db.settings.nextOrderNumber++}`
  const t = now()
  const order = {
    id: newId(9), number, owner: w.owner, name: w.name, items,
    notes: str(body.notes, 160), status: 'new', requestId: requestId || null,
    createdAt: t, updatedAt: t, history: [{ status: 'new', at: t, by: w.owner }]
  }
  db.orders.push(order)
  save()
  ordersChanged(order.owner)
  return order
}

function setStatus(w, id, status) {
  const o = db.orders.find(x => x.id === id)
  if (!o) fail(404, 'That order no longer exists.')
  if (!STATUSES.includes(status)) fail(400, 'Unknown status.')
  if (o.status === status) return o // double tap
  if (!TRANSITIONS[o.status].includes(status)) fail(409, `This order is already ${o.status}. Refresh to see the latest.`)
  o.status = status; o.updatedAt = now()
  o.history.push({ status, at: o.updatedAt, by: w.owner })
  save()
  ordersChanged(o.owner)
  return o
}

function report(days) {
  const out = []
  const today = startOfToday()
  for (let i = days - 1; i >= 0; i--) {
    const from = new Date(today); from.setDate(from.getDate() - i)
    const to = new Date(from); to.setDate(to.getDate() + 1)
    const list = db.orders.filter(o => o.createdAt >= from.getTime() && o.createdAt < to.getTime() && o.status !== 'cancelled')
    out.push({ date: from.getTime(), orders: list.length, drinks: list.reduce((n, o) => n + o.items.reduce((m, it) => m + it.qty, 0), 0) })
  }
  const top = {}
  for (const o of db.orders) if (o.createdAt >= today && o.status !== 'cancelled') for (const it of o.items) top[it.name] = (top[it.name] || 0) + it.qty
  const active = { new: 0, preparing: 0, ready: 0 }
  for (const o of db.orders) if (o.status in active) active[o.status]++
  return { days: out, top: Object.entries(top).sort((a, b) => b[1] - a[1]).slice(0, 6), active }
}

const IMAGE_TYPES = {
  'image/png': ['.png', b => b[0] === 0x89 && b[1] === 0x50],
  'image/jpeg': ['.jpg', b => b[0] === 0xff && b[1] === 0xd8],
  'image/webp': ['.webp', b => b.slice(8, 12).toString() === 'WEBP'],
  'image/gif': ['.gif', b => b.slice(0, 3).toString() === 'GIF']
}

/* ============================== API routes ============================== */

const routes = []
const route = (method, pattern, handler) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), handler })

route('GET', '/api/public', () => ({ cafeName: db.settings.cafeName }))

route('GET', '/api/session', (req) => {
  const w = whoIs(req)
  return { user: w ? { name: w.name, email: w.email, role: w.role } : null }
})

route('POST', '/api/login/email', async (req, res) => {
  const ip = clientIp(req)
  limit('email-login:' + ip, 30, 10 * 60000)
  const { email } = await readJson(req)
  const clean = str(email, 200).toLowerCase()
  if (!EMAIL_RE.test(clean)) fail(400, 'Please enter your full work email, e.g. name@alphax.ae')
  const st = db.staff.find(s => s.email === clean && s.active)
  if (!st) fail(404, 'This email is not on the staff list. Check the spelling, or ask the office administrator to add you.')
  const { token, maxAge } = createSession('staff', st.email, 180)
  setCookie(res, token, maxAge)
  return { user: { name: staffName(st), email: st.email, role: 'employee' } }
})

route('POST', '/api/login/password', async (req, res) => {
  const { email, password } = await readJson(req)
  const clean = str(email, 200).toLowerCase()
  const key = 'pw:' + clientIp(req) + ':' + clean
  limit(key, 8, 15 * 60000)
  const u = db.users.find(x => x.email === clean && x.active)
  if (!u || typeof password !== 'string' || !checkPassword(u, password)) fail(401, 'Wrong email or password.')
  clearLimit(key)
  const { token, maxAge } = createSession('user', u.id, 30)
  setCookie(res, token, maxAge)
  return { user: { name: u.name, email: u.email, role: u.role } }
})

route('POST', '/api/logout', (req, res) => {
  const w = whoIs(req)
  if (w) { delete db.sessions[w.key]; save() }
  setCookie(res, '', 0)
  return { ok: true }
})

route('GET', '/api/menu', (req) => {
  requireUser(req)
  return { products: db.products.filter(p => p.active).sort((a, b) => a.sort - b.sort).map(({ id, name, desc, image }) => ({ id, name, desc, image })) }
})

route('POST', '/api/orders', async (req) => {
  const w = requireUser(req)
  return { order: publicOrder(placeOrder(w, await readJson(req))) }
})

route('GET', '/api/orders/mine', (req) => {
  const w = requireUser(req)
  const since = now() - 7 * 86400000
  return { orders: db.orders.filter(o => o.owner === w.owner && o.createdAt >= since).sort((a, b) => b.createdAt - a.createdAt).slice(0, 30).map(publicOrder) }
})

route('GET', '/api/orders/board', (req) => {
  requireRole(req, 'barista', 'admin')
  const today = startOfToday()
  return { orders: db.orders.filter(o => ['new', 'preparing', 'ready'].includes(o.status) || o.updatedAt >= today).map(publicOrder) }
})

route('POST', '/api/orders/:id/status', async (req, res, p) => {
  const w = requireRole(req, 'barista', 'admin')
  const { status } = await readJson(req)
  return { order: publicOrder(setStatus(w, p.id, status)) }
})

/* ---- admin ---- */

route('GET', '/api/admin/report', (req) => { requireRole(req, 'admin'); return report(7) })

route('GET', '/api/admin/orders', (req) => {
  requireRole(req, 'admin')
  const q = new URL(req.url, 'http://x').searchParams
  const from = q.get('from') ? new Date(q.get('from') + 'T00:00:00').getTime() : startOfToday()
  const to = q.get('to') ? new Date(q.get('to') + 'T00:00:00').getTime() + 86400000 : startOfToday() + 86400000
  const status = q.get('status')
  return { orders: db.orders.filter(o => o.createdAt >= from && o.createdAt < to && (!status || status === 'all' || o.status === status)).sort((a, b) => b.createdAt - a.createdAt).slice(0, 2000).map(publicOrder) }
})

route('GET', '/api/admin/products', (req) => { requireRole(req, 'admin'); return { products: [...db.products].sort((a, b) => a.sort - b.sort) } })

function productFromBody(b, existing = {}) {
  const name = str(b.name, 40)
  if (!name) fail(400, 'A drink needs a name.')
  const image = str(b.image, 200)
  if (image && !/^\/(images|uploads)\/[\w.-]+$/.test(image)) fail(400, 'Choose a picture from the list or upload one.')
  return { ...existing, name, desc: str(b.desc, 100), image: image || '/images/placeholder.svg', active: b.active !== false, sort: Number.isFinite(+b.sort) ? +b.sort : existing.sort ?? db.products.length + 1 }
}
route('POST', '/api/admin/products', async (req) => {
  requireRole(req, 'admin')
  const p = { id: newId(6), ...productFromBody(await readJson(req)) }
  db.products.push(p); save(); broadcast('menu')
  return { product: p }
})
route('PUT', '/api/admin/products/:id', async (req, res, prm) => {
  requireRole(req, 'admin')
  const i = db.products.findIndex(x => x.id === prm.id)
  if (i === -1) fail(404, 'That drink no longer exists.')
  db.products[i] = productFromBody(await readJson(req), db.products[i]); save(); broadcast('menu')
  return { product: db.products[i] }
})
route('DELETE', '/api/admin/products/:id', (req, res, prm) => {
  requireRole(req, 'admin')
  db.products = db.products.filter(x => x.id !== prm.id); save(); broadcast('menu')
  return { ok: true }
})
route('POST', '/api/admin/upload', async (req) => {
  requireRole(req, 'admin')
  const type = String(req.headers['content-type'] || '').split(';')[0]
  const kind = IMAGE_TYPES[type]
  if (!kind) fail(415, 'Please upload a PNG, JPG, WebP or GIF picture.')
  const buf = await readBody(req, 3 * 1024 * 1024)
  if (!kind[1](buf)) fail(415, 'That file is not a valid picture.')
  const file = newId(10) + kind[0]
  fs.writeFileSync(path.join(UPLOAD_DIR, file), buf)
  return { url: '/uploads/' + file }
})

route('GET', '/api/admin/staff', (req) => { requireRole(req, 'admin'); return { staff: [...db.staff].sort((a, b) => staffName(a).localeCompare(staffName(b))) } })
route('POST', '/api/admin/staff', async (req) => {
  requireRole(req, 'admin')
  const body = await readJson(req)
  let rows, skipped = []
  if (typeof body.paste === 'string') ({ rows, skipped } = staffFromRows(parseCsv(body.paste)))
  else {
    const email = str(body.email, 200).toLowerCase(), firstName = str(body.firstName, 40)
    if (!EMAIL_RE.test(email)) fail(400, 'Please enter a valid email address.')
    if (!firstName) fail(400, 'Please enter a first name.')
    rows = [{ email, firstName, lastName: str(body.lastName, 40), active: true }]
  }
  if (!rows.length) fail(400, 'No rows with an email address were found. Paste columns: First name, Last name, Email.')
  for (const r of rows) {
    const ex = db.staff.find(s => s.email === r.email)
    if (ex) Object.assign(ex, r); else db.staff.push(r)
  }
  save()
  return { added: rows.length, skipped }
})
route('PATCH', '/api/admin/staff/:email', async (req, res, prm) => {
  requireRole(req, 'admin')
  const s = db.staff.find(x => x.email === decodeURIComponent(prm.email))
  if (!s) fail(404, 'That person is not on the list.')
  const b = await readJson(req)
  if (typeof b.active === 'boolean') s.active = b.active
  if (b.firstName !== undefined) { const f = str(b.firstName, 40); if (!f) fail(400, 'Please enter a first name.'); s.firstName = f }
  if (b.lastName !== undefined) s.lastName = str(b.lastName, 40)
  if (!s.active) for (const [k, v] of Object.entries(db.sessions)) if (v.kind === 'staff' && v.ref === s.email) delete db.sessions[k]
  save()
  return { staff: s }
})
route('DELETE', '/api/admin/staff/:email', (req, res, prm) => {
  requireRole(req, 'admin')
  const email = decodeURIComponent(prm.email)
  db.staff = db.staff.filter(x => x.email !== email)
  for (const [k, v] of Object.entries(db.sessions)) if (v.kind === 'staff' && v.ref === email) delete db.sessions[k]
  save()
  return { ok: true }
})

const publicUser = (u) => ({ id: u.id, email: u.email, name: u.name, role: u.role, active: u.active })
route('GET', '/api/admin/users', (req) => { requireRole(req, 'admin'); return { users: db.users.map(publicUser) } })
route('POST', '/api/admin/users', async (req) => {
  requireRole(req, 'admin')
  const b = await readJson(req)
  const email = str(b.email, 200).toLowerCase(), name = str(b.name, 60)
  if (!EMAIL_RE.test(email) && !/^[\w.-]{3,40}$/.test(email)) fail(400, 'Please enter an email or a simple username.')
  if (!name) fail(400, 'Please enter a name.')
  if (db.users.some(u => u.email === email)) fail(409, 'An account with that email already exists.')
  const role = b.role === 'admin' ? 'admin' : 'barista'
  const password = randomPassword()
  const u = { id: newId(8), email, name, role, active: true, ...hashPassword(password), createdAt: now() }
  db.users.push(u); save()
  return { user: publicUser(u), password }
})
route('PATCH', '/api/admin/users/:id', async (req, res, prm) => {
  const w = requireRole(req, 'admin')
  const u = db.users.find(x => x.id === prm.id)
  if (!u) fail(404, 'That account no longer exists.')
  const b = await readJson(req)
  if (u.id === w.id && (b.active === false || (b.role && b.role !== 'admin'))) fail(400, 'You cannot remove your own admin access.')
  if (b.role === 'admin' || b.role === 'barista') u.role = b.role
  if (typeof b.active === 'boolean') u.active = b.active
  let password
  if (b.resetPassword) { password = randomPassword(); Object.assign(u, hashPassword(password)) }
  if (b.newPassword !== undefined) {
    if (u.id !== w.id) fail(403, 'You can only choose your own password.')
    if (typeof b.newPassword !== 'string' || b.newPassword.length < 8) fail(400, 'Use at least 8 characters.')
    Object.assign(u, hashPassword(b.newPassword))
  }
  if (!u.active || password) for (const [k, v] of Object.entries(db.sessions)) if (v.kind === 'user' && v.ref === u.id && k !== w.key) delete db.sessions[k]
  save()
  return { user: publicUser(u), password }
})

route('GET', '/api/admin/settings', (req) => { requireRole(req, 'admin'); return { settings: db.settings } })
route('PUT', '/api/admin/settings', async (req) => {
  requireRole(req, 'admin')
  const b = await readJson(req)
  const cafeName = str(b.cafeName, 40)
  if (!cafeName) fail(400, 'Please enter a café name.')
  db.settings.cafeName = cafeName
  db.settings.orderPrefix = str(b.orderPrefix, 5)
  if (b.nextOrderNumber !== undefined && b.nextOrderNumber !== '') {
    const n = Number(b.nextOrderNumber)
    if (!Number.isInteger(n) || n < 1 || n > 999999) fail(400, 'The next order number must be between 1 and 999999.')
    db.settings.nextOrderNumber = n
  }
  save(); broadcast('settings')
  return { settings: db.settings }
})

/* password change for baristas too */
route('POST', '/api/account/password', async (req) => {
  const w = requireUser(req)
  if (w.kind !== 'user') fail(400, 'Employees sign in with email only and have no password.')
  const { current, next } = await readJson(req)
  const u = db.users.find(x => x.id === w.id)
  if (typeof current !== 'string' || !checkPassword(u, current)) fail(401, 'Your current password is wrong.')
  if (typeof next !== 'string' || next.length < 8) fail(400, 'Use at least 8 characters.')
  Object.assign(u, hashPassword(next)); save()
  return { ok: true }
})

/* ============================== static files ============================== */

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' }

function serveStatic(req, res, pathname) {
  let base = PUBLIC_DIR, rel = pathname
  if (pathname.startsWith('/uploads/')) { base = UPLOAD_DIR; rel = pathname.slice('/uploads'.length) }
  if (rel === '/' || !path.extname(rel)) rel = '/index.html' // single-page app
  const file = path.normalize(path.join(base, decodeURIComponent(rel)))
  if (!file.startsWith(base + path.sep)) { res.writeHead(403); return res.end() }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found') }
    const ext = path.extname(file).toLowerCase()
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size }
    headers['Cache-Control'] = ext === '.html' ? 'no-cache' : 'public, max-age=86400'
    if (base === UPLOAD_DIR) headers['Content-Disposition'] = 'inline'
    res.writeHead(200, headers)
    if (req.method === 'HEAD') return res.end()
    fs.createReadStream(file).pipe(res)
  })
}

/* ============================== server ============================== */

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
}

const server = http.createServer(async (req, res) => {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v)
  const { pathname } = new URL(req.url, 'http://local')
  try {
    if (pathname === '/api/events') {
      const w = whoIs(req)
      if (!w) return send(res, 401, { error: 'Please sign in again.' })
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' })
      res.write('retry: 3000\n\n')
      const c = { res, who: w }
      clients.add(c)
      req.on('close', () => clients.delete(c))
      return
    }
    if (pathname.startsWith('/api/')) {
      // Every change must come from our own page (stops other websites from
      // submitting forms to this server with an employee's cookie).
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        if (req.headers['x-coffee'] !== '1') fail(403, 'Request blocked. Please reload the page.')
        const origin = req.headers.origin
        if (origin && new URL(origin).host !== req.headers.host) fail(403, 'Request blocked. Please reload the page.')
      }
      for (const r of routes) {
        if (r.method !== req.method) continue
        const m = r.re.exec(pathname)
        if (m) return send(res, 200, await r.handler(req, res, m.groups || {}))
      }
      fail(404, 'Not found')
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end() }
    serveStatic(req, res, pathname)
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message })
    console.error(new Date().toISOString(), req.method, pathname, e)
    send(res, 500, { error: 'Something went wrong on the coffee server. Please try again.' })
  }
})

/* ============================== command line ============================== */

function cliCreateAdmin(email, name) {
  email = (email || '').toLowerCase()
  if (!email) { console.log('Usage: node server.js create-admin you@company.com "Your Name"'); process.exit(1) }
  let u = db.users.find(x => x.email === email)
  const password = randomPassword()
  if (u) { Object.assign(u, hashPassword(password), { role: 'admin', active: true }); console.log(`\nReset ${email} to admin.`) }
  else { u = { id: newId(8), email, name: name || email, role: 'admin', active: true, ...hashPassword(password), createdAt: now() }; db.users.push(u); console.log(`\nCreated admin ${email}.`) }
  flush()
  console.log(`Password: ${password}\nSign in at http://<this-server>:${PORT}/#staff-login and change it under Admin → My password.\n`)
}

function cliResetPassword(email) {
  const u = db.users.find(x => x.email === (email || '').toLowerCase())
  if (!u) { console.log(`No barista/admin account for ${email}.`); process.exit(1) }
  const password = randomPassword()
  Object.assign(u, hashPassword(password), { active: true })
  for (const [k, v] of Object.entries(db.sessions)) if (v.kind === 'user' && v.ref === u.id) delete db.sessions[k]
  flush()
  console.log(`\nNew password for ${u.email}: ${password}\n`)
}

const [cmd, a1, a2] = process.argv.slice(2)
if (cmd === 'create-admin') { cliCreateAdmin(a1, a2); process.exit(0) }
if (cmd === 'reset-password') { cliResetPassword(a1); process.exit(0) }
if (cmd) { console.log('Unknown command. Use: create-admin EMAIL "NAME"  |  reset-password EMAIL'); process.exit(1) }

/* First start: make an admin account so nobody is locked out. */
if (!db.users.some(u => u.role === 'admin' && u.active)) {
  const password = randomPassword()
  db.users.push({ id: newId(8), email: 'admin', name: 'Administrator', role: 'admin', active: true, ...hashPassword(password), createdAt: now() })
  const note = `First admin account (created ${new Date().toString()})\n\nUsername: admin\nPassword: ${password}\n\nSign in at /#staff-login, then change the password under Admin -> My password,\nand delete this file.\n`
  fs.writeFileSync(path.join(DATA_DIR, 'FIRST-ADMIN-PASSWORD.txt'), note)
  console.log('\n' + '='.repeat(60) + '\n' + note + '='.repeat(60) + '\n')
}
flush()
backup()
housekeeping()
setInterval(() => { backup(); housekeeping() }, 6 * 3600000).unref()

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { flush(); process.exit(0) })
process.on('exit', () => { if (saveTimer) flush() })

server.listen(PORT, HOST, () => {
  const nets = require('os').networkInterfaces()
  const addrs = Object.values(nets).flat().filter(n => n && n.family === 'IPv4' && !n.internal).map(n => n.address)
  console.log(`Office Coffee Station is running.`)
  console.log(`  On this computer:  http://localhost:${PORT}`)
  for (const a of addrs) console.log(`  On the network:    http://${a}:${PORT}`)
  console.log(`  Data folder:       ${DATA_DIR}`)
  console.log(`  Staff on the list: ${db.staff.filter(s => s.active).length}`)
})
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\nPort ${PORT} is already in use. Close the other program or start with a different port, e.g.  PORT=8081 node server.js\n`)
  else console.error(e)
  process.exit(1)
})
