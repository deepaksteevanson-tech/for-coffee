// End-to-end test: starts the real server with an empty, temporary data
// folder and runs the full workflow plus the security rules over HTTP.
//   node tests/test.mjs
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'coffee-test-'))
const PORT = 18000 + Math.floor(Math.random() * 1000)
const BASE = `http://127.0.0.1:${PORT}`

let passed = 0, failed = 0
const ok = (c, label) => { if (c) { passed++; console.log('  ✓', label) } else { failed++; console.log('  ✗', label) } }

function start() {
  const p = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT), HOST: '127.0.0.1', DATA_DIR: DATA }, stdio: ['ignore', 'pipe', 'pipe'] })
  let out = ''
  p.stdout.on('data', d => { out += d }); p.stderr.on('data', d => { out += d })
  return new Promise((resolve, reject) => {
    const t = setInterval(() => { if (out.includes('is running')) { clearInterval(t); resolve({ p, out: () => out }) } }, 50)
    p.on('exit', code => { clearInterval(t); reject(new Error('server exited ' + code + '\n' + out)) })
  })
}
const stop = (s) => new Promise(r => { s.p.once('exit', r); s.p.kill('SIGTERM') })

/** A browser: keeps its own cookie. */
function browser() {
  let cookie = ''
  const call = async (method, url, body, extra = {}) => {
    const headers = { 'X-Coffee': '1', ...(cookie ? { Cookie: cookie } : {}), ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...extra }
    const res = await fetch(BASE + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) })
    const sc = res.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0]
    let data = {}; try { data = await res.json() } catch { /* not json */ }
    return { status: res.status, data, headers: res.headers }
  }
  return { call, get cookie() { return cookie } }
}

let server = await start()
try {
  const firstPw = fs.readFileSync(path.join(DATA, 'FIRST-ADMIN-PASSWORD.txt'), 'utf8').match(/Password: (\S+)/)[1]

  console.log('\nFirst start')
  ok(/Staff on the list: 42/.test(server.out()), 'staff list loaded from seed/staff.csv (42 people)')
  ok(fs.existsSync(path.join(DATA, 'db.json')), 'database file created')
  const anon = browser()
  ok((await anon.call('GET', '/api/menu')).status === 401, 'menu needs sign-in')
  ok((await anon.call('GET', '/api/public')).data.cafeName === 'Office Coffee', 'café name is public')
  const page = await fetch(BASE + '/')
  ok(page.status === 200 && (await page.text()).includes('Order Your Coffee'), 'web page is served')
  ok(page.headers.get('content-security-policy')?.includes("frame-ancestors 'none'"), 'security headers set')
  ok((await fetch(BASE + '/../server.js')).status !== 200 && (await fetch(BASE + '/%2e%2e/server.js')).status !== 200, 'cannot download server files with ../')

  console.log('\nEmployee sign-in (email only)')
  const alex = browser()
  let r = await alex.call('POST', '/api/login/email', { email: 'nobody@alphax.ae' })
  ok(r.status === 404 && /not on the staff list/.test(r.data.error), 'unknown email rejected')
  r = await alex.call('POST', '/api/login/email', { email: '  ABwogi@AlphaX.ae ' })
  ok(r.status === 200 && r.data.user.name === 'Alex Bwogi', `signed in, name from staff list (${r.data.user?.name})`)
  ok(/HttpOnly/.test(r.headers.get('set-cookie')) && /SameSite=Strict/.test(r.headers.get('set-cookie')), 'session cookie is HttpOnly + SameSite=Strict')
  const recep = browser()
  ok((await recep.call('POST', '/api/login/email', { email: 'reception@alphax.ae' })).data.user.name === 'Reception', '"Reception Reception" shown once')

  console.log('\nOrdering')
  const menu = (await alex.call('GET', '/api/menu')).data.products
  ok(menu.length === 12 && menu.some(p => p.name === 'Matcha Vanilla') && menu.some(p => p.name === 'Cortado'), '12 drinks incl. Matcha, Matcha Vanilla, Cortado')
  const cap = menu.find(p => p.name === 'Cappuccino').id, cort = menu.find(p => p.name === 'Cortado').id
  r = await alex.call('POST', '/api/orders', { items: [{ productId: cap, qty: 2 }, { productId: cort, qty: 1 }], notes: 'Extra hot', requestId: 'req-1', name: 'Fake Name' })
  ok(r.status === 200 && r.data.order.number === '101', `order #${r.data.order?.number} created`)
  ok(r.data.order.name === 'Alex Bwogi', 'order carries the staff-list name (typed name ignored)')
  const orderId = r.data.order.id
  r = await alex.call('POST', '/api/orders', { items: [{ productId: cap, qty: 2 }, { productId: cort, qty: 1 }], notes: 'Extra hot', requestId: 'req-1' })
  ok(r.data.order.id === orderId, 'double tap (same request id) returns the same order')
  ok((await alex.call('GET', '/api/orders/mine')).data.orders.length === 1, 'still only one order')
  for (const [items, label] of [[[], 'empty order'], [[{ productId: cap, qty: 0 }], 'quantity 0'], [[{ productId: cap, qty: 11 }], 'quantity 11'], [[{ productId: cap, qty: 1.5 }], 'quantity 1.5'], [[{ productId: cap, qty: '2' }], 'text quantity'], [[{ productId: 'nope', qty: 1 }], 'unknown drink'], [[{ productId: cap, qty: 6 }, { productId: cap, qty: 6 }], 'split quantity over 10']])
    ok((await alex.call('POST', '/api/orders', { items })).status >= 400, `${label} rejected`)

  console.log('\nEmployee restrictions')
  ok((await alex.call('POST', `/api/orders/${orderId}/status`, { status: 'ready' })).status === 403, 'employee cannot change order status')
  ok((await alex.call('GET', '/api/orders/board')).status === 403, 'employee cannot see the barista board')
  ok((await alex.call('GET', '/api/admin/staff')).status === 403, 'employee cannot read the staff list')
  ok((await recep.call('GET', '/api/orders/mine')).data.orders.length === 0, "another employee cannot see Alex's order")
  ok((await alex.call('POST', '/api/orders', { items: [{ productId: cap, qty: 1 }] }, { 'X-Coffee': '' })).status === 403, 'request from another website (no app header) blocked')
  ok((await alex.call('POST', '/api/orders', { items: [{ productId: cap, qty: 1 }] }, { Origin: 'http://evil.example' })).status === 403, 'request with a foreign Origin blocked')

  console.log('\nAdmin & barista accounts')
  const admin = browser()
  ok((await admin.call('POST', '/api/login/password', { email: 'admin', password: 'wrong' })).status === 401, 'wrong admin password rejected')
  ok((await admin.call('POST', '/api/login/password', { email: 'admin', password: firstPw })).data.user?.role === 'admin', 'first admin signs in with the generated password')
  ok((await alex.call('POST', '/api/login/password', { email: 'abwogi@alphax.ae', password: 'x' })).status === 401, 'employees have no password access')
  r = await admin.call('POST', '/api/admin/users', { name: 'Bea Barista', email: 'barista@alphax.ae', role: 'barista' })
  ok(r.status === 200 && r.data.password?.length >= 10, 'admin creates a barista account (password shown once)')
  const baristaPw = r.data.password
  const bea = browser()
  ok((await bea.call('POST', '/api/login/password', { email: 'barista@alphax.ae', password: baristaPw })).data.user?.role === 'barista', 'barista signs in')
  ok((await bea.call('GET', '/api/admin/staff')).status === 403, 'barista cannot open admin pages')
  let lock = 0
  for (let i = 0; i < 9; i++) if ((await browser().call('POST', '/api/login/password', { email: 'barista@alphax.ae', password: 'guess' + i })).status === 429) lock++
  ok(lock > 0, 'repeated wrong passwords are slowed down (rate limit)')

  console.log('\nBarista workflow + live updates')
  // open the live event stream as Alex and count "orders" events
  const ctrl = new AbortController(); let events = 0
  const es = await fetch(BASE + '/api/events', { headers: { Cookie: alex.cookie }, signal: ctrl.signal })
  ;(async () => { try { for await (const chunk of es.body) if (String(Buffer.from(chunk)).includes('event: orders')) events++ } catch { /* aborted */ } })()
  await new Promise(r => setTimeout(r, 150))
  const board = (await bea.call('GET', '/api/orders/board')).data.orders
  ok(board.length === 1 && board[0].name === 'Alex Bwogi' && board[0].notes === 'Extra hot', 'barista sees the order with name and notes')
  ok((await bea.call('POST', `/api/orders/${orderId}/status`, { status: 'completed' })).status === 409, 'cannot skip from New to Collected')
  for (const st of ['preparing', 'ready', 'ready']) await bea.call('POST', `/api/orders/${orderId}/status`, { status: st })
  await new Promise(r => setTimeout(r, 200))
  ok((await alex.call('GET', '/api/orders/mine')).data.orders[0].status === 'ready', "Alex's page sees READY")
  ok(events >= 2, `Alex's browser was notified live (${events} events)`)
  await bea.call('POST', `/api/orders/${orderId}/status`, { status: 'completed' })
  ok((await bea.call('GET', '/api/orders/board')).data.orders[0].status === 'completed', 'marked as collected')
  ctrl.abort()

  console.log('\nAdmin: menu, staff list, settings')
  r = await admin.call('POST', '/api/admin/products', { name: 'Iced Latte', desc: 'Over ice', image: '/images/latte.svg' })
  ok(r.status === 200, 'admin adds a drink')
  ok((await admin.call('POST', '/api/admin/products', { name: 'Bad', image: 'javascript:alert(1)' })).status === 400, 'unsafe picture address rejected')
  await admin.call('PUT', `/api/admin/products/${cort}`, { name: 'Cortado', desc: '', image: '/images/cortado.svg', active: false })
  ok(!(await alex.call('GET', '/api/menu')).data.products.some(p => p.id === cort), 'hidden drink disappears from the menu')
  ok((await alex.call('POST', '/api/orders', { items: [{ productId: cort, qty: 1 }] })).status === 409, 'hidden drink cannot be ordered')
  const png = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8ffff3f0005fe02fea7d6a4c40000000049454e44ae426082', 'hex')
  r = await fetch(BASE + '/api/admin/upload', { method: 'POST', headers: { Cookie: admin.cookie, 'X-Coffee': '1', 'Content-Type': 'image/png' }, body: png })
  const up = await r.json()
  ok(r.status === 200 && (await fetch(BASE + up.url)).status === 200, 'admin uploads a photo and it is served')
  r = await fetch(BASE + '/api/admin/upload', { method: 'POST', headers: { Cookie: admin.cookie, 'X-Coffee': '1', 'Content-Type': 'image/png' }, body: '<svg onload=alert(1)>' })
  ok(r.status === 415, 'fake image (script) upload rejected')
  r = await admin.call('POST', '/api/admin/staff', { paste: 'First Name\tLast Name\tEmail\nNew\tJoiner\tnjoiner@alphax.ae\nbad line' })
  ok(r.data.added === 1, 'paste import adds a new joiner, skips header')
  ok((await browser().call('POST', '/api/login/email', { email: 'njoiner@alphax.ae' })).data.user?.name === 'New Joiner', 'new joiner can sign in')
  await admin.call('PATCH', '/api/admin/staff/' + encodeURIComponent('abwogi@alphax.ae'), { active: false })
  ok((await alex.call('GET', '/api/menu')).status === 401, "disabling a person signs them out immediately")
  ok((await browser().call('POST', '/api/login/email', { email: 'abwogi@alphax.ae' })).status === 404, 'disabled person cannot sign in')
  await admin.call('PUT', '/api/admin/settings', { cafeName: 'AlphaX Coffee', orderPrefix: 'A-', nextOrderNumber: 1 })
  ok((await anon.call('GET', '/api/public')).data.cafeName === 'AlphaX Coffee', 'café name changed')
  ok((await recep.call('POST', '/api/orders', { items: [{ productId: cap, qty: 1 }] })).data.order.number === 'A-1', 'order numbers restart with prefix (#A-1)')
  ok((await admin.call('PATCH', `/api/admin/users/${(await admin.call('GET', '/api/admin/users')).data.users.find(u => u.email === 'admin').id}`, { active: false })).status === 400, 'admin cannot disable themself')
  const rep = (await admin.call('GET', '/api/admin/report')).data
  ok(rep.days.length === 7 && rep.days[6].orders === 2 && rep.days[6].drinks === 4, `report: today ${rep.days[6].orders} orders, ${rep.days[6].drinks} drinks`)

  console.log('\nRestart: nothing is lost')
  await stop(server)
  server = await start()
  ok((await recep.call('GET', '/api/orders/mine')).data.orders[0]?.number === 'A-1', 'orders survive a restart, employee stays signed in')
  ok((await bea.call('GET', '/api/orders/board')).status === 200, 'barista stays signed in after restart')
  ok(fs.readdirSync(path.join(DATA, 'backups')).length >= 1, 'daily backup written to data/backups')
} catch (e) {
  failed++; console.error(e)
} finally {
  await stop(server).catch(() => {})
  fs.rmSync(DATA, { recursive: true, force: true })
}
console.log(`\n${passed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)
