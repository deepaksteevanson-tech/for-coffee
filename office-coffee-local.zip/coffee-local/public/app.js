/* Office Coffee — browser app (no frameworks, no build step). */
(() => {
  'use strict'
  const $ = (id) => document.getElementById(id)
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v) } catch { return d } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch { /* private mode */ } }
  }
  const MAXQ = 10
  const STATUS = { new: 'Received', preparing: 'Preparing', ready: 'Ready', completed: 'Collected', cancelled: 'Cancelled' }
  const MSG = { new: 'Sent — the barista will start it shortly.', preparing: 'Your drinks are being made.', ready: 'READY! Please collect it at the coffee station.' }
  const PICTURES = ['espresso', 'americano', 'cappuccino', 'latte', 'spanish-latte', 'flat-white', 'cortado', 'mocha', 'matcha', 'matcha-vanilla', 'hot-chocolate', 'tea', 'placeholder'].map(k => `/images/${k}.svg`)
  const time = (t) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  const ago = (t) => { const m = Math.floor((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : `${Math.floor(m / 60)} h ${m % 60} min ago` }
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10)
  const itemsText = (o) => o.items.map(i => `${i.qty}× ${esc(i.name)}`).join(', ')

  const S = {
    me: null, cafe: 'Office Coffee', menu: null, mine: [], board: [], cart: store.get('coffee-cart', {}), picks: {},
    view: null, bTab: 'new', aTab: 'overview', sound: store.get('coffee-sound', false), sending: false, pendingId: null,
    seen: null, lastMine: {}, es: null
  }

  /* ---------------- server calls ---------------- */
  async function api(method, url, body, raw) {
    let res
    try {
      res = await fetch(url, {
        method, credentials: 'same-origin',
        headers: { 'X-Coffee': '1', ...(body !== undefined ? { 'Content-Type': raw ? body.type : 'application/json' } : {}) },
        body: body === undefined ? undefined : raw ? body : JSON.stringify(body)
      })
    } catch { throw new Error("Can't reach the coffee server. Check your Wi-Fi or network cable and try again.") }
    let data = {}
    try { data = await res.json() } catch { /* empty */ }
    if (res.status === 401 && S.me && !url.startsWith('/api/login')) { S.me = null; showLogin(); }
    if (!res.ok) { const e = new Error(data.error || `The server answered ${res.status}.`); e.status = res.status; throw e }
    return data
  }

  /* ---------------- sound & toasts ---------------- */
  let actx
  const unlock = () => { try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); if (actx.state === 'suspended') actx.resume() } catch { /* no audio */ } }
  document.addEventListener('pointerdown', unlock, { once: true })
  function chime(kind) {
    try {
      unlock(); if (!actx) return
      ;(kind === 'ready' ? [659, 880, 1319] : [880, 1175]).forEach((f, i) => {
        const o = actx.createOscillator(), g = actx.createGain(), t = actx.currentTime + i * 0.18
        o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.35, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.4)
        o.connect(g).connect(actx.destination); o.start(t); o.stop(t + 0.45)
      })
    } catch { /* ignore */ }
  }
  let toastTimer
  function toast(text, kind) {
    const t = $('toast'); t.textContent = text; t.className = 'toast' + (kind ? ' ' + kind : ''); t.hidden = false
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true }, kind === 'ready' ? 7000 : kind === 'err' ? 5000 : 2600)
  }
  function modal(html, wire) {
    $('modal').innerHTML = html; $('modal').hidden = false; $('modal-back').hidden = false
    const close = () => { $('modal').hidden = true; $('modal-back').hidden = true }
    $('modal-back').onclick = close
    $('modal').querySelectorAll('[data-close]').forEach(b => { b.onclick = close })
    if (wire) wire(close)
    const f = $('modal').querySelector('input, button'); if (f) f.focus()
  }
  function confirmBox(text, okLabel, onOk) {
    modal(`<h2>${esc(text)}</h2><div class="row spread"><button class="btn ghost" data-close>Keep</button><button class="btn danger" id="m-ok">${esc(okLabel)}</button></div>`,
      (close) => { $('m-ok').onclick = () => { close(); onOk() } })
  }
  function showSecret(title, who, secret) {
    modal(`<h2>${esc(title)}</h2><p>Give this to <b>${esc(who)}</b>. It is shown only once.</p><div class="secret">${esc(secret)}</div><button class="btn" data-close>Done</button>`)
  }

  /* ---------------- sign in ---------------- */
  function setCafe(name) { S.cafe = name || 'Office Coffee'; document.querySelectorAll('.js-cafe').forEach(e => { e.textContent = S.cafe }); if (!document.title.startsWith('✅')) document.title = S.cafe }

  function showLogin() {
    if (S.es) { S.es.close(); S.es = null }
    $('app').hidden = true; $('v-login').hidden = false
    const staff = location.hash === '#staff-login'
    $('login-title').textContent = staff ? 'Barista sign in' : 'Order Your Coffee'
    $('login-sub').textContent = staff ? 'For baristas and administrators.' : 'Enter your work email to start. No password needed.'
    $('login-email-label').textContent = staff ? 'Email or username' : 'Work email'
    $('login-email').type = staff ? 'text' : 'email'
    $('login-email').placeholder = staff ? 'name@alphax.ae' : 'name@alphax.ae'
    $('login-email').value = staff ? '' : store.get('coffee-last-email', '')
    $('pw-wrap').hidden = !staff
    $('login-password').required = staff
    $('login-btn').textContent = staff ? 'Sign in' : 'Continue'
    $('login-switch').textContent = staff ? 'Employee sign in' : 'Barista / admin sign in'
    $('login-switch').href = staff ? '#' : '#staff-login'
    $('login-err').hidden = true
    setTimeout(() => $('login-email').focus(), 50)
  }

  $('login-form').addEventListener('submit', async (e) => {
    e.preventDefault()
    const staff = location.hash === '#staff-login'
    const email = $('login-email').value.trim(), err = $('login-err')
    err.hidden = true
    if (!email) { err.textContent = staff ? 'Enter your email or username.' : 'Enter your work email.'; err.hidden = false; return }
    $('login-btn').disabled = true
    try {
      const r = staff
        ? await api('POST', '/api/login/password', { email, password: $('login-password').value })
        : await api('POST', '/api/login/email', { email })
      if (!staff) store.set('coffee-last-email', email.toLowerCase())
      $('login-password').value = ''
      S.me = r.user
      location.hash = S.me.role === 'admin' ? 'admin' : S.me.role === 'barista' ? 'barista' : 'order'
      startApp()
    } catch (ex) { err.textContent = ex.message; err.hidden = false }
    finally { $('login-btn').disabled = false }
  })

  $('logout').onclick = async () => {
    try { await api('POST', '/api/logout', {}) } catch { /* offline: still forget locally */ }
    S.me = null; S.cart = {}; store.set('coffee-cart', {}); location.hash = ''; showLogin()
  }

  /* ---------------- live connection ---------------- */
  function setConn(state) {
    const c = $('conn')
    c.className = 'pill' + (state === 'live' ? ' live' : state === 'off' ? ' off' : '')
    c.textContent = state === 'live' ? '● Live' : state === 'off' ? '● Reconnecting…' : 'Connecting…'
  }
  function connect() {
    if (S.es) S.es.close()
    const es = new EventSource('/api/events')
    S.es = es
    es.onopen = () => { setConn('live'); refreshAll() }
    es.onerror = () => { setConn('off'); if (es.readyState === EventSource.CLOSED) setTimeout(() => { if (S.me && S.es === es) checkSession() }, 4000) }
    es.addEventListener('orders', () => { loadMine(); if (isStaff()) loadBoard() })
    es.addEventListener('menu', () => loadMenu())
    es.addEventListener('settings', () => api('GET', '/api/public').then(r => setCafe(r.cafeName)).catch(() => {}))
  }
  window.addEventListener('online', () => { $('offline').hidden = true; refreshAll() })
  window.addEventListener('offline', () => { $('offline').hidden = false; setConn('off') })
  setInterval(() => { if (S.me && document.visibilityState === 'visible') refreshAll() }, 60000)
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && S.me) refreshAll() })

  const isStaff = () => S.me && (S.me.role === 'barista' || S.me.role === 'admin')
  function refreshAll() { loadMenu(); loadMine(); if (isStaff()) loadBoard(); if (S.view === 'admin') renderAdmin() }

  /* ---------------- routing ---------------- */
  function route() {
    if (!S.me) { showLogin(); return }
    let v = location.hash.slice(1)
    if (v === 'staff-login' || !v) v = S.me.role === 'admin' ? 'admin' : S.me.role === 'barista' ? 'barista' : 'order'
    if (v === 'barista' && !isStaff()) v = 'order'
    if (v === 'admin' && S.me.role !== 'admin') v = 'order'
    S.view = v
    for (const id of ['order', 'barista', 'admin']) $('v-' + id).hidden = id !== v
    document.querySelectorAll('#nav a').forEach(a => {
      a.classList.toggle('on', a.dataset.view === v)
      if (a.dataset.role) a.hidden = !a.dataset.role.split(' ').includes(S.me.role)
    })
    renderCartBar()
    if (v === 'barista') renderBoard()
    if (v === 'admin') renderAdmin()
  }
  window.addEventListener('hashchange', () => { if (S.me) route(); else showLogin() })

  async function checkSession() {
    try {
      const [pub, ses] = await Promise.all([api('GET', '/api/public'), api('GET', '/api/session')])
      setCafe(pub.cafeName)
      S.me = ses.user
      if (S.me) startApp(); else showLogin()
    } catch (e) {
      $('v-login').hidden = false
      $('login-err').textContent = e.message; $('login-err').hidden = false
    }
  }
  function startApp() {
    $('v-login').hidden = true; $('app').hidden = false
    $('me').textContent = S.me.name
    $('as-name').textContent = S.me.name
    S.seen = null; S.lastMine = {}
    route(); connect(); refreshAll()
  }

  /* ---------------- menu ---------------- */
  const product = (id) => (S.menu || []).find(p => p.id === id)
  async function loadMenu() {
    try {
      const r = await api('GET', '/api/menu'); S.menu = r.products
      let changed = false
      for (const id of Object.keys(S.cart)) if (!product(id)) { delete S.cart[id]; changed = true }
      if (changed) saveCart()
      renderMenu(); renderCartBar()
    } catch (e) { if (!S.menu) $('menu').innerHTML = `<div class="empty">${esc(e.message)}</div>` }
  }
  function renderMenu() {
    const el = $('menu')
    if (!S.menu) return
    if (!S.menu.length) { el.innerHTML = `<div class="empty">No drinks are available right now.${S.me.role === 'admin' ? ' Add some under <b>Admin → Menu</b>.' : ''}</div>`; return }
    el.innerHTML = S.menu.map(p => {
      const inCart = S.cart[p.id] || 0, pick = S.picks[p.id] || 1
      return `<article class="card ${inCart ? 'in' : ''}">
        <button class="pic" data-add="${esc(p.id)}" aria-label="Add ${pick} ${esc(p.name)}"><img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy">${inCart ? `<span class="count">${inCart} in order</span>` : ''}</button>
        <div class="card-body"><h3>${esc(p.name)}</h3><p>${esc(p.desc)}</p>
          <div class="row">
            <span class="qty"><button data-pick="${esc(p.id)}" data-d="-1" aria-label="Fewer" ${pick <= 1 ? 'disabled' : ''}>−</button><output>${pick}</output><button data-pick="${esc(p.id)}" data-d="1" aria-label="More" ${pick >= MAXQ ? 'disabled' : ''}>+</button></span>
            <button class="btn" data-add="${esc(p.id)}">Add</button>
          </div></div></article>`
    }).join('')
  }
  $('menu').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return
    if (b.dataset.pick) { const id = b.dataset.pick; S.picks[id] = Math.max(1, Math.min(MAXQ, (S.picks[id] || 1) + Number(b.dataset.d))); renderMenu(); return }
    if (b.dataset.add) {
      const id = b.dataset.add, n = S.picks[id] || 1
      S.cart[id] = Math.min(MAXQ, (S.cart[id] || 0) + n); S.picks[id] = 1; S.pendingId = null; saveCart()
      toast(`${n} × ${product(id)?.name} added`); renderMenu(); renderCartBar()
    }
  })

  /* ---------------- cart ---------------- */
  const saveCart = () => store.set('coffee-cart', S.cart)
  const cartCount = () => Object.values(S.cart).reduce((a, b) => a + b, 0)
  function renderCartBar() {
    const n = cartCount()
    $('cart-bar').hidden = !n || S.view !== 'order' || !$('sheet').hidden
    $('cart-n').textContent = n; $('cart-txt').textContent = n === 1 ? 'drink' : 'drinks'
  }
  function renderLines() {
    $('lines').innerHTML = Object.keys(S.cart).filter(product).map(id => `<li><img src="${esc(product(id).image)}" alt=""><span class="nm">${esc(product(id).name)}</span>
      <span class="qty sm"><button data-line="${esc(id)}" data-d="-1" aria-label="Fewer">−</button><output>${S.cart[id]}</output><button data-line="${esc(id)}" data-d="1" aria-label="More" ${S.cart[id] >= MAXQ ? 'disabled' : ''}>+</button></span></li>`).join('')
  }
  const openSheet = () => { renderLines(); $('send-err').hidden = true; $('sheet').hidden = false; $('sheet-back').hidden = false; renderCartBar() }
  const closeSheet = () => { $('sheet').hidden = true; $('sheet-back').hidden = true; renderCartBar() }
  $('cart-bar').onclick = openSheet; $('close-sheet').onclick = closeSheet; $('sheet-back').onclick = closeSheet
  $('lines').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-line]'); if (!b) return
    const id = b.dataset.line, q = (S.cart[id] || 0) + Number(b.dataset.d)
    if (q <= 0) delete S.cart[id]; else S.cart[id] = Math.min(MAXQ, q)
    S.pendingId = null; saveCart()
    if (!cartCount()) closeSheet(); else renderLines()
    renderMenu(); renderCartBar()
  })
  $('notes').addEventListener('input', () => { S.pendingId = null })

  $('send').onclick = async () => {
    if (S.sending) return
    const err = $('send-err'); err.hidden = true
    const items = Object.keys(S.cart).filter(product).map(id => ({ productId: id, qty: S.cart[id] }))
    if (!items.length) { err.textContent = 'Your order is empty.'; err.hidden = false; return }
    S.sending = true; $('send').disabled = true; $('send').textContent = 'Sending…'
    // The same id is re-sent on a retry, so a double tap or a network blip never creates two orders.
    S.pendingId = S.pendingId || uid()
    try {
      const r = await api('POST', '/api/orders', { items, notes: $('notes').value.trim(), requestId: S.pendingId })
      S.cart = {}; saveCart(); S.pendingId = null; $('notes').value = ''
      closeSheet(); renderMenu(); toast(`Order #${r.order.number} sent to the barista`)
      window.scrollTo({ top: 0, behavior: 'smooth' }); loadMine()
    } catch (e) { err.textContent = e.message + (e.status ? '' : ' Your drinks are kept — press Send Order again.'); err.hidden = false }
    finally { S.sending = false; $('send').disabled = false; $('send').textContent = 'Send Order' }
  }

  /* ---------------- my orders ---------------- */
  async function loadMine() {
    try {
      const r = await api('GET', '/api/orders/mine'); S.mine = r.orders
      for (const o of S.mine) {
        if (S.lastMine[o.id] && S.lastMine[o.id] !== 'ready' && o.status === 'ready') {
          chime('ready'); try { navigator.vibrate && navigator.vibrate([200, 100, 200]) } catch { /* ignore */ }
          toast(`☕ Order #${o.number} is ready — please collect it`, 'ready')
        }
      }
      S.lastMine = Object.fromEntries(S.mine.map(o => [o.id, o.status]))
      renderMine()
    } catch { /* shown by connection pill */ }
  }
  function renderMine() {
    const active = S.mine.filter(o => ['new', 'preparing', 'ready'].includes(o.status)).sort((a, b) => a.createdAt - b.createdAt)
    const past = S.mine.filter(o => !['new', 'preparing', 'ready'].includes(o.status)).slice(0, 8)
    const ready = active.find(o => o.status === 'ready')
    document.title = ready ? `✅ #${ready.number} is READY` : S.cafe
    const idx = { new: 0, preparing: 1, ready: 2 }
    $('mine').innerHTML = active.map(o => `<div class="track ${o.status === 'ready' ? 'is-ready' : ''}">
      <div class="top"><span class="num">#${esc(o.number)}</span><span class="badge ${o.status}">${STATUS[o.status]}</span></div>
      <div class="msg">${MSG[o.status]}</div>
      <div class="muted">${itemsText(o)}${o.notes ? ' · ' + esc(o.notes) : ''}</div>
      <div class="steps">${['Sent', 'Preparing', 'Ready', 'Collected'].map((s, i) => `<span class="${i <= idx[o.status] ? 'on' : ''}">${s}</span>`).join('')}</div></div>`).join('')
    $('history-wrap').hidden = !past.length
    $('history').innerHTML = past.map(o => `<div class="hist-row"><span class="num">#${esc(o.number)}</span><span class="what">${itemsText(o)}</span><span class="muted">${new Date(o.createdAt).toLocaleDateString([], { weekday: 'short' })} ${time(o.createdAt)}</span><span class="badge ${o.status}">${STATUS[o.status]}</span></div>`).join('')
  }

  /* ---------------- barista ---------------- */
  const BTABS = [['new', 'New'], ['preparing', 'Preparing'], ['ready', 'Ready'], ['done', 'Done today']]
  const NEXT = { new: ['preparing', 'Start preparing'], preparing: ['ready', 'Mark as ready'], ready: ['completed', 'Mark as collected'] }
  const BACK = { preparing: ['new', 'Back to New'], ready: ['preparing', 'Back to Preparing'] }
  async function loadBoard() {
    try {
      const r = await api('GET', '/api/orders/board')
      const fresh = r.orders.filter(o => o.status === 'new' && S.seen && !S.seen.has(o.id))
      if (fresh.length && S.sound) chime('new')
      S.seen = new Set([...(S.seen || []), ...r.orders.map(o => o.id)])
      S.board = r.orders; renderBoard()
    } catch { /* pill shows connection */ }
  }
  function renderBoard() {
    if (S.view !== 'barista') return
    const g = {
      new: S.board.filter(o => o.status === 'new').sort((a, b) => a.createdAt - b.createdAt),
      preparing: S.board.filter(o => o.status === 'preparing').sort((a, b) => a.createdAt - b.createdAt),
      ready: S.board.filter(o => o.status === 'ready').sort((a, b) => a.updatedAt - b.updatedAt),
      done: S.board.filter(o => o.status === 'completed' || o.status === 'cancelled').sort((a, b) => b.updatedAt - a.updatedAt)
    }
    $('btabs').innerHTML = BTABS.map(([k, l]) => `<button class="tab ${k === 'new' && g.new.length ? 'has-new' : ''}" role="tab" aria-selected="${S.bTab === k}" data-tab="${k}">${l}<span class="c">${g[k].length}</span></button>`).join('')
    const list = g[S.bTab]
    $('tickets').innerHTML = !list.length ? `<div class="empty">No ${BTABS.find(t => t[0] === S.bTab)[1].toLowerCase()} orders.</div>` : list.map((o, i) => {
      const nx = NEXT[o.status], bk = BACK[o.status], first = i === 0 && (S.bTab === 'new' || S.bTab === 'preparing')
      return `<article class="ticket ${o.status} ${first ? 'next' : ''}">${first ? '<span class="next-tag">NEXT UP</span>' : ''}
        <div class="top"><span class="num">#${esc(o.number)}</span><span class="badge ${o.status}">${STATUS[o.status]}</span></div>
        <div class="who">${esc(o.name)}</div>
        <div class="muted">${time(o.createdAt)} · ${ago(o.createdAt)}</div>
        <ul class="items">${o.items.map(it => `<li><img src="${esc(it.image)}" alt=""><b>${it.qty}×</b><span>${esc(it.name)}</span></li>`).join('')}</ul>
        ${o.notes ? `<div class="note">📝 ${esc(o.notes)}</div>` : ''}
        ${nx ? `<div class="acts"><button class="btn big go-${nx[0]}" data-set="${nx[0]}" data-id="${esc(o.id)}">${nx[1]}</button>
          <div class="row spread">${bk ? `<button class="link" data-set="${bk[0]}" data-id="${esc(o.id)}">↶ ${bk[1]}</button>` : '<span></span>'}
          ${o.status !== 'ready' ? `<button class="link danger" data-cancel="${esc(o.id)}" data-num="${esc(o.number)}">Cancel order</button>` : ''}</div></div>` : ''}
      </article>`
    }).join('')
  }
  $('btabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) { S.bTab = b.dataset.tab; renderBoard() } })
  async function changeStatus(id, status, btn) {
    if (btn) btn.disabled = true
    try { await api('POST', `/api/orders/${encodeURIComponent(id)}/status`, { status }); await loadBoard() }
    catch (e) { toast(e.message, 'err'); loadBoard() }
  }
  $('tickets').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b || b.disabled) return
    if (b.dataset.set) changeStatus(b.dataset.id, b.dataset.set, b)
    if (b.dataset.cancel) confirmBox(`Cancel order #${b.dataset.num}?`, 'Cancel order', () => changeStatus(b.dataset.cancel, 'cancelled'))
  })
  setInterval(() => { if (S.view === 'barista') renderBoard() }, 30000)
  const renderSound = () => { $('sound').textContent = S.sound ? '🔔 Sound on' : '🔕 Sound off'; $('sound').setAttribute('aria-pressed', S.sound) }
  $('sound').onclick = () => { S.sound = !S.sound; store.set('coffee-sound', S.sound); unlock(); if (S.sound) chime('new'); renderSound() }
  renderSound()

  /* ---------------- admin ---------------- */
  const ATABS = [['overview', 'Overview'], ['orders', 'Orders'], ['menu', 'Menu'], ['staff', 'Staff list'], ['accounts', 'Barista accounts'], ['settings', 'Settings']]
  $('atabs').addEventListener('click', (e) => { const b = e.target.closest('[data-atab]'); if (b) { S.aTab = b.dataset.atab; renderAdmin() } })
  let adminRender = 0
  async function renderAdmin() {
    if (S.view !== 'admin') return
    $('atabs').innerHTML = ATABS.map(([k, l]) => `<button class="tab" role="tab" data-atab="${k}" aria-selected="${S.aTab === k}">${l}</button>`).join('')
    const mine = ++adminRender
    const body = $('admin-body')
    try {
      const html = await ADMIN[S.aTab]()
      if (mine !== adminRender) return
      // keep what someone is typing when live updates refresh the screen
      if (body.contains(document.activeElement) && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName) && body.dataset.tab === S.aTab) return
      body.dataset.tab = S.aTab
      body.innerHTML = html
      body.onclick = null
      WIRE[S.aTab] && WIRE[S.aTab]()
    } catch (e) { body.innerHTML = `<div class="notice err">${esc(e.message)}</div>` }
  }

  const A = {} // admin screen state
  const ADMIN = {
    async overview() {
      const r = await api('GET', '/api/admin/report')
      const today = r.days[r.days.length - 1]
      const max = Math.max(1, ...r.days.map(d => d.drinks))
      return `<div class="stats">
          <div class="stat"><span>Orders today</span><strong>${today.orders}</strong></div>
          <div class="stat"><span>Drinks today</span><strong>${today.drinks}</strong></div>
          <div class="stat new"><span>Waiting</span><strong>${r.active.new}</strong></div>
          <div class="stat preparing"><span>Preparing</span><strong>${r.active.preparing}</strong></div>
          <div class="stat ready"><span>Ready to collect</span><strong>${r.active.ready}</strong></div></div>
        <div class="two">
          <div class="panel"><h2>Last 7 days</h2><div class="table-wrap"><table><thead><tr><th>Day</th><th>Orders</th><th>Drinks</th><th></th></tr></thead><tbody>
            ${[...r.days].reverse().map(d => `<tr><td>${new Date(d.date).toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' })}</td><td class="num-c">${d.orders}</td><td class="num-c">${d.drinks}</td><td class="bar-cell"><span class="barline" style="width:${(d.drinks / max) * 100}%"></span></td></tr>`).join('')}
          </tbody></table></div></div>
          <div class="panel"><h2>Most ordered today</h2>${r.top.length ? `<table><tbody>${r.top.map(([n, q]) => `<tr><td>${esc(n)}</td><td class="num-c"><b>${q}</b></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No orders yet today.</p>'}</div>
        </div>`
    },
    async orders() {
      const d = new Date(), today = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
      A.from = A.from || today; A.to = A.to || today; A.status = A.status || 'all'
      const r = await api('GET', `/api/admin/orders?from=${A.from}&to=${A.to}&status=${A.status}`)
      const live = r.orders.filter(o => o.status !== 'cancelled')
      return `<div class="panel"><div class="fields">
          <div><label for="f-from">From</label><input type="date" id="f-from" value="${A.from}"></div>
          <div><label for="f-to">To</label><input type="date" id="f-to" value="${A.to}"></div>
          <div><label for="f-status">Status</label><select id="f-status">${['all', ...Object.keys(STATUS)].map(s => `<option value="${s}" ${A.status === s ? 'selected' : ''}>${s === 'all' ? 'All' : STATUS[s]}</option>`).join('')}</select></div>
          <div><b>${r.orders.length}</b> orders · <b>${live.reduce((n, o) => n + o.items.reduce((m, i) => m + i.qty, 0), 0)}</b> drinks</div></div></div>
        <div class="panel table-wrap"><table><thead><tr><th>#</th><th>Time</th><th>Name</th><th>Drinks</th><th>Notes</th><th>Status</th></tr></thead><tbody>
          ${r.orders.length ? r.orders.map(o => `<tr><td><b>${esc(o.number)}</b></td><td>${new Date(o.createdAt).toLocaleDateString([], { day: 'numeric', month: 'short' })} ${time(o.createdAt)}</td><td>${esc(o.name)}</td><td>${itemsText(o)}</td><td class="muted">${esc(o.notes)}</td><td><span class="badge ${o.status}">${STATUS[o.status]}</span></td></tr>`).join('') : '<tr><td colspan="6" class="muted">No orders in this period.</td></tr>'}
        </tbody></table></div>`
    },
    async menu() {
      const r = await api('GET', '/api/admin/products'); A.products = r.products
      return `<div class="row spread"><p class="muted">Hidden drinks disappear from the menu straight away. Old orders keep their drink names.</p><button class="btn" id="p-add">+ Add a drink</button></div>
        <div class="panel">${r.products.map(p => `<div class="mrow ${p.active ? '' : 'off'}"><img src="${esc(p.image)}" alt=""><div class="nm"><b>${esc(p.name)}</b> ${p.active ? '' : '<span class="badge off">Hidden</span>'}<div class="muted small">${esc(p.desc)}</div></div>
          <button class="btn small ghost" data-pedit="${esc(p.id)}">Edit</button><button class="btn small ghost" data-ptoggle="${esc(p.id)}">${p.active ? 'Hide' : 'Show'}</button><button class="link danger" data-pdel="${esc(p.id)}">Remove</button></div>`).join('') || '<p class="muted">No drinks yet.</p>'}</div>`
    },
    async staff() {
      const r = await api('GET', '/api/admin/staff'); A.staff = r.staff
      const q = (A.q || '').toLowerCase()
      const list = r.staff.filter(s => !q || `${s.firstName} ${s.lastName} ${s.email}`.toLowerCase().includes(q))
      return `<p class="muted">People on this list sign in with just their work email. Their name appears on every order.</p>
        <div class="two">
          <form class="panel" id="s-add"><h2>Add a person</h2><div class="fields">
            <div><label for="s-first">First name</label><input type="text" id="s-first" maxlength="40" required></div>
            <div><label for="s-last">Last name</label><input type="text" id="s-last" maxlength="40"></div></div>
            <label for="s-email">Work email</label><input type="email" id="s-email" required placeholder="name@alphax.ae">
            <div><button class="btn">Add to staff list</button></div></form>
          <div class="panel"><h2>Paste a list</h2><label for="s-paste">Copy the columns First name, Last name, Email from Excel and paste here</label>
            <textarea id="s-paste" rows="5" placeholder="Alex&#9;Bwogi&#9;abwogi@alphax.ae"></textarea>
            <div><button class="btn ghost" id="s-import">Import</button></div><p class="muted small">Existing people are updated. Nobody is deleted.</p></div>
        </div>
        <div class="row spread"><input type="text" id="s-q" placeholder="Search name or email" value="${esc(A.q || '')}" style="max-width:320px"><span class="muted">${r.staff.filter(s => s.active).length} can sign in · ${r.staff.length} on the list</span></div>
        <div class="panel table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Status</th><th></th></tr></thead><tbody>
          ${list.map(s => `<tr class="${s.active ? '' : 'off'}"><td>${esc(s.firstName)} ${esc(s.lastName)}</td><td>${esc(s.email)}</td><td>${s.active ? '<span class="badge ready">Can sign in</span>' : '<span class="badge off">Disabled</span>'}</td>
            <td style="white-space:nowrap"><button class="btn small ghost" data-stoggle="${esc(s.email)}" data-on="${s.active ? 1 : 0}">${s.active ? 'Disable' : 'Enable'}</button> <button class="link danger" data-sdel="${esc(s.email)}">Remove</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted">Nobody matches.</td></tr>'}
        </tbody></table></div>`
    },
    async accounts() {
      const r = await api('GET', '/api/admin/users')
      return `<p class="muted">Baristas and admins sign in with a password at <b>Barista / admin sign in</b>. A new password is shown once when you create or reset an account.</p>
        <form class="panel" id="u-add"><h2>New barista or admin</h2><div class="fields">
          <div><label for="u-name">Name</label><input type="text" id="u-name" maxlength="60" required></div>
          <div><label for="u-email">Email or username</label><input type="text" id="u-email" required placeholder="barista@alphax.ae"></div>
          <div><label for="u-role">Role</label><select id="u-role"><option value="barista">Barista</option><option value="admin">Admin</option></select></div>
          <div><button class="btn">Create account</button></div></div></form>
        <div class="panel table-wrap"><table><thead><tr><th>Name</th><th>Sign in as</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody>
          ${r.users.map(u => `<tr class="${u.active ? '' : 'off'}"><td>${esc(u.name)}${u.email === S.me.email ? ' <span class="muted">(you)</span>' : ''}</td><td>${esc(u.email)}</td><td>${u.role === 'admin' ? 'Admin' : 'Barista'}</td><td>${u.active ? '<span class="badge ready">Active</span>' : '<span class="badge off">Disabled</span>'}</td>
            <td style="white-space:nowrap">${u.email === S.me.email ? '' : `<button class="btn small ghost" data-urole="${esc(u.id)}" data-to="${u.role === 'admin' ? 'barista' : 'admin'}">Make ${u.role === 'admin' ? 'barista' : 'admin'}</button> <button class="btn small ghost" data-ureset="${esc(u.id)}" data-who="${esc(u.name)}">Reset password</button> <button class="link ${u.active ? 'danger' : ''}" data-uactive="${esc(u.id)}" data-to="${u.active ? 0 : 1}">${u.active ? 'Disable' : 'Enable'}</button>`}</td></tr>`).join('')}
        </tbody></table></div>
        <form class="panel" id="pw-form"><h2>My password</h2><div class="fields">
          <div><label for="pw-cur">Current password</label><input type="password" id="pw-cur" required autocomplete="current-password"></div>
          <div><label for="pw-new">New password (8+ characters)</label><input type="password" id="pw-new" minlength="8" required autocomplete="new-password"></div>
          <div><button class="btn">Change my password</button></div></div></form>`
    },
    async settings() {
      const r = await api('GET', '/api/admin/settings'); const s = r.settings
      return `<form class="panel" id="set-form" style="max-width:720px"><h2>Café settings</h2>
        <label for="set-name">Café name</label><input type="text" id="set-name" maxlength="40" value="${esc(s.cafeName)}" required>
        <div class="fields">
          <div><label for="set-prefix">Order number prefix</label><input type="text" id="set-prefix" maxlength="5" value="${esc(s.orderPrefix)}" placeholder="e.g. A-"></div>
          <div><label for="set-next">Next order number</label><input type="number" id="set-next" min="1" max="999999" value="${s.nextOrderNumber}"></div>
        </div>
        <p class="muted small">Tip: set the next number back to 101 each morning for short numbers.</p>
        <div><button class="btn">Save settings</button></div></form>`
    }
  }

  const WIRE = {
    orders() {
      for (const [id, key] of [['f-from', 'from'], ['f-to', 'to'], ['f-status', 'status']]) $(id).onchange = (e) => { A[key] = e.target.value; $(id).blur(); renderAdmin() }
    },
    menu() {
      $('p-add').onclick = () => productForm({ name: '', desc: '', image: PICTURES[0], active: true })
      $('admin-body').onclick = async (e) => {
        const b = e.target.closest('button'); if (!b) return
        const p = A.products.find(x => x.id === (b.dataset.pedit || b.dataset.ptoggle || b.dataset.pdel))
        if (!p) return
        if (b.dataset.pedit) productForm(p)
        if (b.dataset.ptoggle) { try { await api('PUT', `/api/admin/products/${p.id}`, { ...p, active: !p.active }); renderAdmin() } catch (ex) { toast(ex.message, 'err') } }
        if (b.dataset.pdel) confirmBox(`Remove ${p.name} from the menu?`, 'Remove', async () => { try { await api('DELETE', `/api/admin/products/${p.id}`); renderAdmin() } catch (ex) { toast(ex.message, 'err') } })
      }
    },
    staff() {
      $('s-q').oninput = (e) => { A.q = e.target.value; clearTimeout(A.qt); A.qt = setTimeout(async () => { const el = $('s-q'); const pos = el.selectionStart; el.blur(); await renderAdmin(); const n = $('s-q'); n.focus(); n.setSelectionRange(pos, pos) }, 250) }
      $('s-add').onsubmit = async (e) => {
        e.preventDefault()
        try { await api('POST', '/api/admin/staff', { firstName: $('s-first').value, lastName: $('s-last').value, email: $('s-email').value }); toast(`${$('s-first').value} can now sign in`); document.activeElement.blur(); renderAdmin() }
        catch (ex) { toast(ex.message, 'err') }
      }
      $('s-import').onclick = async () => {
        try { const r = await api('POST', '/api/admin/staff', { paste: $('s-paste').value }); toast(`Imported ${r.added} people${r.skipped.length ? `, skipped ${r.skipped.length} line(s)` : ''}`); document.activeElement.blur(); renderAdmin() }
        catch (ex) { toast(ex.message, 'err') }
      }
      $('admin-body').onclick = (e) => {
        const b = e.target.closest('button'); if (!b) return
        if (b.dataset.stoggle) api('PATCH', `/api/admin/staff/${encodeURIComponent(b.dataset.stoggle)}`, { active: b.dataset.on !== '1' }).then(renderAdmin).catch(ex => toast(ex.message, 'err'))
        if (b.dataset.sdel) confirmBox(`Remove ${b.dataset.sdel} from the staff list?`, 'Remove', () => api('DELETE', `/api/admin/staff/${encodeURIComponent(b.dataset.sdel)}`).then(renderAdmin).catch(ex => toast(ex.message, 'err')))
      }
    },
    accounts() {
      $('u-add').onsubmit = async (e) => {
        e.preventDefault()
        try { const r = await api('POST', '/api/admin/users', { name: $('u-name').value, email: $('u-email').value, role: $('u-role').value }); document.activeElement.blur(); await renderAdmin(); showSecret('Account created', `${r.user.name} (${r.user.email})`, r.password) }
        catch (ex) { toast(ex.message, 'err') }
      }
      $('pw-form').onsubmit = async (e) => {
        e.preventDefault()
        try { await api('POST', '/api/account/password', { current: $('pw-cur').value, next: $('pw-new').value }); $('pw-cur').value = ''; $('pw-new').value = ''; toast('Password changed') }
        catch (ex) { toast(ex.message, 'err') }
      }
      $('admin-body').onclick = async (e) => {
        const b = e.target.closest('button'); if (!b || b.closest('form')) return
        try {
          if (b.dataset.urole) { await api('PATCH', `/api/admin/users/${b.dataset.urole}`, { role: b.dataset.to }); renderAdmin() }
          if (b.dataset.uactive) { await api('PATCH', `/api/admin/users/${b.dataset.uactive}`, { active: b.dataset.to === '1' }); renderAdmin() }
          if (b.dataset.ureset) { const r = await api('PATCH', `/api/admin/users/${b.dataset.ureset}`, { resetPassword: true }); showSecret('New password', b.dataset.who, r.password) }
        } catch (ex) { toast(ex.message, 'err') }
      }
    },
    settings() {
      $('set-form').onsubmit = async (e) => {
        e.preventDefault()
        try { const r = await api('PUT', '/api/admin/settings', { cafeName: $('set-name').value, orderPrefix: $('set-prefix').value, nextOrderNumber: $('set-next').value }); setCafe(r.settings.cafeName); document.activeElement.blur(); toast('Settings saved'); renderAdmin() }
        catch (ex) { toast(ex.message, 'err') }
      }
    }
  }

  function productForm(p) {
    let image = p.image
    const pics = () => [...new Set([image, ...PICTURES])].map(src => `<button type="button" data-pic="${esc(src)}" aria-pressed="${src === image}"><img src="${esc(src)}" alt=""></button>`).join('')
    modal(`<h2>${p.id ? 'Edit drink' : 'Add a drink'}</h2>
      <form class="form" id="pf">
        <label for="pf-name">Name</label><input type="text" id="pf-name" maxlength="40" required value="${esc(p.name)}">
        <label for="pf-desc">Description</label><input type="text" id="pf-desc" maxlength="100" value="${esc(p.desc)}">
        <label>Picture</label><div class="pics" id="pf-pics">${pics()}</div>
        <label for="pf-file" class="btn small ghost" style="justify-self:start">Upload a photo…</label><input type="file" id="pf-file" accept="image/png,image/jpeg,image/webp,image/gif" hidden>
        <div class="row spread"><button type="button" class="btn ghost" data-close>Cancel</button><button class="btn">Save</button></div>
      </form>`, (close) => {
      $('pf-pics').onclick = (e) => { const b = e.target.closest('[data-pic]'); if (b) { image = b.dataset.pic; $('pf-pics').innerHTML = pics() } }
      $('pf-file').onchange = async (e) => {
        const f = e.target.files[0]; if (!f) return
        if (f.size > 3 * 1024 * 1024) return toast('That photo is larger than 3 MB. Please use a smaller one.', 'err')
        try { const r = await api('POST', '/api/admin/upload', f, true); image = r.url; $('pf-pics').innerHTML = pics(); toast('Photo uploaded') }
        catch (ex) { toast(ex.message, 'err') }
      }
      $('pf').onsubmit = async (e) => {
        e.preventDefault()
        const body = { ...p, name: $('pf-name').value, desc: $('pf-desc').value, image }
        try { if (p.id) await api('PUT', `/api/admin/products/${p.id}`, body); else await api('POST', '/api/admin/products', body); close(); renderAdmin(); loadMenu() }
        catch (ex) { toast(ex.message, 'err') }
      }
    })
  }

  /* ---------------- start ---------------- */
  $('offline').hidden = navigator.onLine
  checkSession()
})()
