#!/bin/sh
# Office Coffee Station - start on Linux / macOS.  Usage:  ./start.sh
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Install the LTS version from https://nodejs.org (or: sudo apt install nodejs)"
  exit 1
fi
exec node server.js
