@echo off
REM Office Coffee Station - start on Windows (double-click this file).
REM Close this window to stop the server. To run it in the background
REM all the time, see README.md -> "Run it as a Windows service".
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js is not installed. Download the LTS version from https://nodejs.org
  echo then run this file again.
  echo.
  pause
  exit /b 1
)
if "%PORT%"=="" set PORT=8080
title Office Coffee Station (port %PORT%)
node server.js
pause
