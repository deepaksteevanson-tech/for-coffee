# ☕ Office Coffee Station — local server edition

Free office coffee ordering that runs on **your own server**. No cloud, no accounts to buy, no database to install, works without internet.

- **Employees** open the site, type their **work email** (no password), pick drinks, press **Send Order**. Their name comes from the staff list automatically. Their screen turns green with a chime when the order is **Ready**.
- **Baristas** sign in with a password and see orders arrive instantly: *Start preparing → Mark as ready → Mark as collected*.
- **Admins** manage the menu (with photos), the staff list, barista accounts, order numbers and see daily reports.

Your 42 staff from `seed/staff.csv` are loaded the first time the server starts. The menu has 12 drinks, including Matcha, Matcha Vanilla and Cortado.

---

## 1. What you need

| | |
|---|---|
| A computer that stays on during office hours | Windows 10/11, Windows Server, or Linux. A small PC or a VM is plenty (it uses ~50 MB RAM). |
| **Node.js 18 or newer** (LTS) | <https://nodejs.org> → download the LTS installer, Next → Next → Finish. Check with `node -v`. |
| A fixed address for the server | Give it a **static IP** or a DHCP reservation (e.g. `192.168.1.20`), ideally plus a DNS name like `coffee.alphax.local`. |

There is **nothing else to install** — no `npm install` needed. The package uses only Node.js itself.

---

## 2. Quick start (5 minutes, Windows)

1. Copy the `coffee-local` folder to the server, e.g. `C:\CoffeeStation`.
2. Double-click **`start-windows.bat`**. A window opens and shows:
   ```
   Office Coffee Station is running.
     On this computer:  http://localhost:8080
     On the network:    http://192.168.1.20:8080
   ```
3. **First admin password:** it is printed in that window and saved in `data\FIRST-ADMIN-PASSWORD.txt`.
4. Allow other PCs to reach it — open **PowerShell as Administrator** and run:
   ```powershell
   New-NetFirewallRule -DisplayName "Office Coffee" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow -Profile Domain,Private
   ```
5. From another PC or phone on the office Wi-Fi, open `http://192.168.1.20:8080` (your server's address). Type your work email → you're in.

**Linux:** `./start.sh` (or `node server.js`). Firewall: `sudo ufw allow 8080/tcp`.

---

## 3. First-time setup

1. Open `http://<server>:8080/#staff-login` (or click **Barista / admin sign in** on the login page).
2. Sign in as **`admin`** with the password from `data/FIRST-ADMIN-PASSWORD.txt`.
3. **Admin → Barista accounts → My password**: change it to your own. Then **delete** `FIRST-ADMIN-PASSWORD.txt`.
4. **Admin → Barista accounts → New barista**: create an account for each barista. A password is shown **once** — give it to them.
5. **Admin → Settings**: set the café name (shown on every screen).
6. **Admin → Staff list**: check the 42 people are there. Add new joiners or paste a list from Excel any time.

Tip: on the barista's tablet, open the site, sign in, and **Add to Home screen** — it then opens full-screen like an app. Tap **🔕 Sound off** once to switch the new-order chime on.

---

## 4. Run it all the time (background service)

The quick start stops when you close the window. For daily use, run it as a service so it starts with the server and restarts by itself.

### Windows — with NSSM (free, recommended)
1. Download NSSM from <https://nssm.cc/download>, unzip, copy `win64\nssm.exe` to `C:\CoffeeStation`.
2. PowerShell as Administrator:
   ```powershell
   cd C:\CoffeeStation
   .\nssm.exe install OfficeCoffee "C:\Program Files\nodejs\node.exe" "C:\CoffeeStation\server.js"
   .\nssm.exe set OfficeCoffee AppDirectory C:\CoffeeStation
   .\nssm.exe set OfficeCoffee AppStdout C:\CoffeeStation\data\server.log
   .\nssm.exe set OfficeCoffee AppStderr C:\CoffeeStation\data\server.log
   .\nssm.exe set OfficeCoffee Start SERVICE_AUTO_START
   .\nssm.exe start OfficeCoffee
   ```
3. It now appears in **services.msc** as *OfficeCoffee*. Stop/start it there.

### Linux — systemd
See the comments at the top of `deploy/coffee.service` (6 commands). Logs: `journalctl -u coffee -f`.

### Docker
```bash
docker compose up -d
docker compose logs coffee        # first admin password is printed here
```

---

## 5. Where the data lives — and backups

Everything is in the **`data`** folder:

| File | What |
|---|---|
| `data/db.json` | The database: menu, staff list, accounts (passwords are hashed), orders, settings |
| `data/backups/db-YYYY-MM-DD.json` | Automatic daily copy, last 14 days kept |
| `data/uploads/` | Drink photos uploaded by admins |

- **Back up the whole `data` folder** with your normal server backup. It's small.
- **Restore:** stop the service, copy a backup over `data/db.json`, start the service.
- **Move to a new server:** copy the whole folder, start it there.
- Orders older than 365 days are removed automatically; signed-in sessions expire (employees 180 days, baristas 30 days).

---

## 6. Optional: a nicer address and HTTPS

- **DNS:** ask whoever runs your DNS (often the Windows domain controller) to add an A record `coffee` → `192.168.1.20`. Then staff use `http://coffee.alphax.local:8080`.
- **Port 80 / HTTPS:** put it behind IIS (with URL Rewrite + ARR), Nginx or Caddy as a reverse proxy, then start the server with `COOKIE_SECURE=1` and `TRUST_PROXY=1`. Example Caddy line: `coffee.alphax.local { reverse_proxy 127.0.0.1:8080 }`.
- Plain `http://` on the office network is acceptable for free coffee because there are no employee passwords. Use HTTPS if baristas sign in over Wi-Fi you don't fully control.

Settings (environment variables): `PORT` (default 8080), `HOST` (0.0.0.0 = whole network, 127.0.0.1 = this PC only), `DATA_DIR`, `COOKIE_SECURE`, `TRUST_PROXY`.

---

## 7. Security — what protects what

| Rule | How |
|---|---|
| Only people on the staff list can order | Email checked against the active staff list on the server |
| Names can't be faked by typing | The server takes the name from the staff list, never from the browser |
| Only baristas/admins change orders | Every action is checked on the server by role |
| Barista/admin passwords are safe at rest | Stored as scrypt hashes with a salt, never in plain text |
| Password guessing is slowed down | 8 wrong tries → 15 minutes wait |
| Leavers lose access immediately | Disabling someone on the staff list signs them out everywhere |
| Other websites can't send orders as you | Session cookie is HttpOnly + SameSite=Strict, plus a required app header and origin check |
| Uploads can't carry scripts | Only real PNG/JPG/WebP/GIF files (checked by content), max 3 MB |
| Strict browser security headers | Content-Security-Policy, no framing, no MIME sniffing |

**The trade-off you chose:** employees have no password, so someone who knows a colleague's email could order a coffee as them. That's reasonable for free coffee. Email sign-in can **never** reach barista or admin functions.

---

## 8. Testing

```bash
node tests/test.mjs
```
Starts a throw-away copy of the server and runs 58 checks: sign-in, ordering, double-tap protection, invalid quantities, permissions, live notifications, uploads, staff list, settings, and a restart to prove nothing is lost.

**Manual check after installing** (2 minutes): phone = employee, tablet = barista.
1. Phone: sign in with your email → add 2 Cappuccino → Send Order → you get e.g. **#101**.
2. Tablet: #101 appears under **New** without refreshing (chime if sound is on) → **Start preparing** → **Mark as ready**.
3. Phone: turns green, chimes, tab title shows "✅ #101 is READY".

---

## 9. 🛠 IT support runbook

| Ticket | Likely cause | Fix |
|---|---|---|
| "The site doesn't open" from other PCs | Service stopped, firewall, wrong IP | On the server open `http://localhost:8080`. If that works → firewall rule (section 2) or the IP changed (use a reservation). If not → start the service / check `data/server.log` |
| "This email is not on the staff list" | New joiner, typo, or disabled | Admin → Staff list: search, **Add** or **Enable** |
| Wrong name on orders | Spelling on the staff list | Admin → Staff list: re-add the same email with the right name (it updates). Person signs out and in |
| Barista forgot password | — | Admin → Barista accounts → **Reset password**. Admin locked out: on the server run `node server.js reset-password admin` |
| "Too many attempts" | 8 wrong passwords | Wait 15 minutes, or reset the password |
| Orders don't appear live; pill says **Reconnecting…** | Wi-Fi drop, server restarting, proxy buffering | It reconnects by itself. Behind Nginx add `proxy_buffering off;` for `/api/events` |
| No chime | Browsers block sound until the page is tapped once; device muted | Tap the page / the Sound button once after opening it; check volume |
| "Port 8080 is already in use" | Another program uses it | Start with another port: `set PORT=8081` (Windows) / `PORT=8081 ./start.sh` |
| Server says `db.json is damaged` | Disk full / power cut during write (very unlikely) | Copy the newest `data/backups/db-*.json` over `data/db.json`, start again |
| Everyone signed out after moving servers | Sessions are in `db.json` | Copy the whole `data` folder, not just some files |

**Where to look:** the server window or `data/server.log` (errors are printed with time and address), the browser's **F12 → Console / Network** (status 401 = not signed in, 403 = not allowed, 404 = not found, 409 = conflict such as a hidden drink, 429 = too many tries).

---

## 10. What's in the package

```
coffee-local/
├─ server.js              ← the whole server (no dependencies)
├─ public/                ← the web app: index.html, app.js, style.css, images/
├─ seed/staff.csv         ← your staff list, loaded on first start
├─ tests/test.mjs         ← automated end-to-end test
├─ start-windows.bat      ← double-click to run on Windows
├─ start.sh               ← run on Linux/macOS
├─ deploy/coffee.service  ← Linux service file
├─ Dockerfile, docker-compose.yml
└─ data/                  ← created on first start (database, backups, photos)
```

### How it works (for the curious)
- **One Node.js process** serves the web pages and a small JSON API.
- **Storage** is one JSON file, kept in memory and saved safely (write to a temp file, then swap) so a power cut can't leave half a file.
- **Live updates** use *Server-Sent Events*: each open page keeps one connection to `/api/events`; when an order changes, the server sends a one-line "orders changed" message and the page reloads just that data. Browsers reconnect automatically if the network drops.
